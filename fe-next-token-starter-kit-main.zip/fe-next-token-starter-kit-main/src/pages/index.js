const Home = () => {
  return <>Home Page</>
}

export default Home
