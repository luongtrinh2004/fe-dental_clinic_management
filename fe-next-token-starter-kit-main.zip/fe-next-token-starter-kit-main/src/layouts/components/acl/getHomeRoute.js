/**
 *  Set Home URL based on User Roles
 */
const getHomeRoute = () => {
  return '/home'
}

export default getHomeRoute
