


const Translations = ({ text }) => {
  
  

  return <>{text}</>
}

export default Translations
