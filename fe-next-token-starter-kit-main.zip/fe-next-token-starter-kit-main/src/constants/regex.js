export const VALID_PASSWORD_REGEX = /^(?=.*[a-z])(?=.*\d)[\w\S]{6,}$/
